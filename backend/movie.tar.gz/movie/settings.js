module.exports = { 
  cookieSecret: 'movie', 
  db: 'movie', 
  host: 'localhost',
  port: 27017
}; 